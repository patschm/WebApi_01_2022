export { ProductGroupsModule} from './product-groups.module';
export { ProductGroupListComponent} from './product-group-list/product-group-list.component';
export { ProductGroupDetailComponent} from './product-group-detail/product-group-detail.component';
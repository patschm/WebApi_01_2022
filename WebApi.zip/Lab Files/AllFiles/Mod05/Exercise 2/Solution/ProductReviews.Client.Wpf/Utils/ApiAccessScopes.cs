using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductReviews.Client.Wpf.Utils
{
    public static class ApiAccessScopes
    {
        public const string Read = "api://79221685-706a-42de-bb1a-b6c095e034a4/Data.Read";
        public const string Write = "api://79221685-706a-42de-bb1a-b6c095e034a4/Data.Write";
    }
}
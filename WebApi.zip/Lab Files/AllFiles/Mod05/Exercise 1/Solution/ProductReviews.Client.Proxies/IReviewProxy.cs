using ProductReviews.DAL.EntityFramework.Entities;

namespace ProductReviews.Client.Proxies
{
    public interface IReviewProxy: IProxy<Review>
    {
    }
}
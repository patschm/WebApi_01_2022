using ProductReviews.DAL.EntityFramework.Entities;

namespace ProductReviews.Client.Proxies
{
    public interface IBrandProxy: IProxy<Brand>
    {
    }
}
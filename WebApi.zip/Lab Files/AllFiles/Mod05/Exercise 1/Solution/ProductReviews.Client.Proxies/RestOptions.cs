using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductReviews.Client.Proxies
{
    public class RestOptions
    {
        public string? RestUrl { get; set; }
    }
}